from email.policy import default
from odoo import fields, models, api, _



class VisitInsight(models.Model):
    _name = 'visit.insight'
    _description = 'Visits'
    _inherits = {'res.partner': 'partner_id'}
    _inherit = ['mail.thread', 'mail.activity.mixin']

    partner_id = fields.Many2one('res.partner', required=True, ondelete='cascade', tracking=True)
    visitor_pic = fields.Image(string='Visitor Pic', tracking=True)
    no_of_visitor = fields.Integer(string='Number of Visitor', default=1, tracking=True)
    visitor_id = fields.Char(string="Visitor ID", readonly=True, default=lambda self: _('New'),
                             tracking=True)
    is_vehicle = fields.Selection([('no', 'No'), ('yes', 'Yes')], default='no', tracking=True)
    vehicle_number = fields.Char(string='Visitor Vehicle no.', tracking=True)
    vehicle_pic = fields.Image(string='Number Plate Pic', tracking=True)
    phone_no = fields.Char(string="Contact Number", related='partner_id.phone', readonly=False,
                           tracking=True)
    mail_id = fields.Char(string="Email ID", related='partner_id.email', readonly=False, tracking=True)
    check_in_datetime = fields.Datetime(string="CheckIn Date", default=lambda self: fields.Datetime.now(),
                                        tracking=True)
    check_out_datetime = fields.Datetime(string="CheckOut Date", tracking=True)
    purpose_of_visit = fields.Char(string="Purpose", required=True, tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('checkin', 'CheckIn'),
        ('checkout', 'CheckOut'),
        ('cancelled', 'Cancelled')], default='draft', string='Status', tracking=True)

    # New field to link with hr.employee
    employee_ids = fields.Many2one('hr.employee', string="Meeting With", tracking=True)
    # Related fields to fetch employee details
    meeting_with = fields.Char(string="Employee Name", related='employee_ids.name', required=True,
                               tracking=True)
    employee_contact = fields.Char(string="Employee Contact", related='employee_ids.mobile_phone',
                                   tracking=True)
    department = fields.Char(string="Department", related='employee_ids.department_id.name', required=True,
                             tracking=True)
    department_ids = fields.Many2one('hr.department', string="Department", tracking=True)
    email_id = fields.Char(string="Email ID", related='employee_ids.work_email', required=True,
                           tracking=True)

    duration = fields.Float(string="Duration (Hours)", compute='_compute_duration', tracking=True)

    belongings_ids = fields.One2many('personal.belongings', 'visit_insight_ids', string="Belongings Id",
                                     tracking=True)
    visitor_count = fields.Integer(string="Visits", compute='compute_visitor_count', readonly=True,
                                   tracking=True)
    visitor_count_by_number = fields.Integer(string="Visits", compute='compute_visitor_count_by_number', readonly=True,
                                             tracking=True)

    reference_id = fields.Char(string="Reference ID", readonly=True, tracking=True)
    formatted_duration = fields.Char("Duration (formatted)", compute="_compute_formatted_duration", tracking=True)

    is_individual = fields.Selection([('individual', 'Individual'), ('department', 'Department')], default='individual',
                                     tracking=True)
    auth_by = fields.Many2one('hr.employee', string="Authenticated By", tracking=True)
    @api.onchange('department_ids')
    def employee_manage(self):
        for record in self:
            if record.department_ids and not record.employee_ids:
                record.employee_ids = record.department_ids.manager_id
                record.employee_contact = record.department_ids.manager_id.mobile_phone
                record.email_id = record.department_ids.manager_id.work_email
            else:
                pass

    def compute_visitor_count(self):
        visitor_count = self.env['visit.insight'].search_count([('visitor_id', '=', self.visitor_id)])
        self.visitor_count = visitor_count

    def compute_visitor_count_by_number(self):
        visitor_count_by_number = self.env['visit.insight'].search_count([('phone_no', '=', self.phone_no)])
        self.visitor_count_by_number = visitor_count_by_number

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        """Automatically fill visitor details if the visitor already exists."""
        if self.partner_id:
            existing_visit = self.search([('phone_no', '=', self.phone_no)], limit=1)

            if existing_visit:
                # Populate fields with existing data
                self.visitor_id = existing_visit.visitor_id
                self.mail_id = existing_visit.mail_id
                self.phone_no = existing_visit.phone_no
            else:
                # Generate a new visitor ID for a new partner
                self.visitor_id = 'New'

    @api.model
    def create(self, vals):
        partner_id = vals.get('partner_id')

        # Check if a visitor with the same partner_id exists
        existing_visit = self.search([('partner_id', '=', partner_id)], limit=1)

        if existing_visit:
            vals['visitor_id'] = existing_visit.visitor_id
            vals['mail_id'] = existing_visit.mail_id
            vals['phone_no'] = existing_visit.phone_no
        else:
            vals['visitor_id'] = self.env['ir.sequence'].next_by_code('visit.insight') or 'New'

        return super(VisitInsight, self).create(vals)

    def action_checkin(self):
        for rec in self:
            rec.state = 'checkin'

    def action_checkout(self):
        for rec in self:
            rec.state = 'checkout'

    def action_cancel(self):
        for rec in self:
            rec.visitor_id = 'New'
            self.phone_no = False
            self.check_in_datetime = False
            # self.check_out_datetime = False
            self.employee_ids = False
            self.meeting_with = False
            self.employee_contact = False
            self.mail_id = False
            self.department_ids = False
            self.belongings_ids = False
            self.purpose_of_visit = 'No purpose specified'

            rec.state = 'cancelled'

    @api.depends('check_in_datetime', 'check_out_datetime')
    def _compute_duration(self):
        for record in self:
            if record.check_in_datetime and record.check_out_datetime:
                # Calculate duration in seconds
                duration = record.check_out_datetime - record.check_in_datetime
                total_seconds = int(duration.total_seconds())
                record.duration = total_seconds / 3600
            else:
                record.duration = 0.0

    @api.depends('duration')
    def _compute_formatted_duration(self):
        for record in self:
            if record.duration:
                hours = int(record.duration)
                minutes = int((record.duration - hours) * 60)
                record.formatted_duration = f"{hours}h {minutes}m"
            else:
                record.formatted_duration = "0h 0m"  # Default value if duration is not set

    def action_checkout(self):
        for record in self:
            record.check_out_datetime = fields.Datetime.now()
            record.state = 'checkout'

    @api.onchange('check_in_datetime', 'check_out_datetime')
    def _onchange_datetime(self):
        if self.check_in_datetime:
            # if not self.check_in_datetime or not self.check_out_datetime:
            self.state = 'checkin'
        else:
            self.state = 'draft'
        if self.check_out_datetime:
            # if not self.check_in_datetime or not self.check_out_datetime:
            self.state = 'checkout'

    def action_view_visits(self):
        # This method now correctly fetches every visit for the same visitor
        return {
            'type': 'ir.actions.act_window',
            'name': 'All Visits of Visitor',
            'view_mode': 'tree,form',
            'res_model': 'visit.insight',
            'domain': [('phone_no', '=', self.phone_no)],  # This domain will fetch all visits for the same visitor
            'context': dict(self._context),
        }

    def action_send_email_reminder(self):
        self.send_email_reminder()

    # @api.multi
    def send_email_reminder(self):
        # Get the reference to the email template
        template = self.env.ref('gate_book.email_template_visitor_notify')  # Adjust with your module and template ID

        if not template:
            raise ValueError("Email template not found.")

        for visitor in self:
            try:
                # Send the email using the template
                template.send_mail(visitor.id, force_send=True)
                # Log success
                print(f"Email sent successfully to visitor {visitor.id}")
            except Exception as e:
                # Log any exceptions
                print(f"Error sending email to visitor {visitor.id}: {str(e)}")

