from odoo import fields, models
from odoo.odoo.tools.populate import compute

class GateBook(models.Model):
    _name = 'gate.book'
    _description = 'Gate Book'
    _rec_name = 'visitor_id'

    visitor_name = fields.Char(string="Visitor Name", required=True, tracking=True)
    visitor_id = fields.Char(string="Visitor Id", required=True, tracking=True)
    street = fields.Char(string="Street", required=True, tracking=True)
    city = fields.Char(string="City", required=True, tracking=True)
    zip_code = fields.Char(string="Area Code", tracking=True)
    state = fields.Char(string="State", required=True, tracking=True)
    company_name = fields.Char(string="Company Name", tracking=True)
    phone_no = fields.Char(string="Contact Number", required=True, tracking=True)
    mail_id = fields.Char(string="Email Id", tracking=True)
    id_proof = fields.Char(string="ID Proof of Visitors", tracking=True)
    visitor_count = fields.Integer(string="Visits", compute='compute_visitor_count', readonly=True,
                                   tracking=True)
    # print_options = fields.Selection(related='print_option_id.print_options', string='Print Options', store=True)
    def compute_visitor_count(self):
        visitor_count = self.env['visit.insight'].search_count([('visitor_ids', '=', self.visitor_id)])
        self.visitor_count = visitor_count
