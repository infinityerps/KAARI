from odoo import fields, models


class Personal_Belongings(models.Model):
    _name = 'personal.belongings'
    _description = 'Personal Belongings'

    visit_insight_ids = fields.Many2one('visit.insight', string="Belongings ID", ondelete='cascade',tracking=True)

    belongings_name = fields.Char(string="Belongings Name", tracking=True)
    belongings_count = fields.Integer(string="Belongings Count", tracking=True)
    permission = fields.Selection([
        ('allowed', 'Allowed'),
        ('not_allowed', 'Not Allowed')], default='not_allowed', string='Permission', tracking=True)
