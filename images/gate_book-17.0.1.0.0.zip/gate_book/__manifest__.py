{
    'name': 'Gate Book System',
    'version': '17.0.1.0.0',
    'summary': 'Gate Book  Management System',
    'author': "Namah Softech Pvt Ltd",
    'maintainer': 'Namah Softech Pvt Ltd',
    'website': "https://namahsoftech.com/",
    'category': 'Gate book Management System',
    'description': 'Manage Gate Entries: Oversee vehicle arrivals and departures at the gate. Maintain Check-In and Check-Out records. Gate Log Details: Keep accurate records of all entries and exits through the gate. Issue Gate Pass: Provide identification passes for vehicle access.',
    'depends': ['base', 'hr', 'contacts', 'mail', 'snailmail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'data/data.xml',
        'data/email_template.xml',
        'views/visits_insight_view.xml',
        'views/todays_visit_view.xml',
        'views/personal_belongings.xml',
        'views/menuitems.xml',
        'views/ir_actions_printing_options.xml',
        'report/report.xml',
        'report/visitor_pass_template.xml',
        'report/visitor_report_template.xml',
        'report/belongings_pass_template.xml'
    ],
    'assets': {
        'web.assets_backend': [
            'gate_book/static/src/js/PrintOptionsModal.js',
            'gate_book/static/src/js/qweb_action.js',
            'gate_book/static/src/**/*.xml'
        ]
    },
    'images': ['static/description/banner.gif'],
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'auto_install': False,
}
